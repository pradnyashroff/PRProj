<?php
	class ftgs_model extends CI_Model
	{
		function __construct() 
		{
			parent::__construct();
		}
		//profile fetch
		public function profile_fetch($emp_code) {
			$condition = "emp_code =" . "'" . $emp_code . "' ";
			$this->db->select('*');
			$this->db->from('employee_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query;
			}
			else {
				return false;
			}
		}
		//pr type
		public function pr_type() {
			$condition = "pt_id = 14";
			$this->db->select('*');
			$this->db->from('pt_type');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query;
			}
			else {
				return false;
			}
		}
		//plant
		public function plant() {
			$this->db->select('*');
			$this->db->from('plant_master');
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query;
			}
			else {
				return false;
			}
		}
		//department
		public function department($dept_id) {
			$condition = "dept_code="."'".$dept_id."'";
			$this->db->select('dept_name');
			$this->db->from('department_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query->row()->dept_name;
			} else {
				return false;
			}
		}
		//ftgs pr items fetch
		public function ftgs_item($emp_code) {
			$condition = "ftgs_pr_id =" . "'" . $emp_code . "' ";
			$this->db->select('*');
			$this->db->from('ftgs_pr_items');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query;
			}
			else {
				return false;
			}
		}
		//add ftgs pr
		 public function add_ftgs_pr($data) 
		 {
			$this->load->database();
			$this->db->insert('ftgs_pr_items', $data);
		}
		//delete items
		 function deleteitem($id)
		{
			$this->db->query("delete from ftgs_pr_items where ftgs_item_id='".$id."'");
		}
		//update ftgs items
		 public function update_ftgs_pr($data, $editId) 
		 {
			$this->db->where('ftgs_item_id', $editId);
			$this->db->update('ftgs_pr_items',$data);
        }
		//update ftgs items code
		 public function update_itemCode($data, $editId) 
		 {
			$this->db->where('ftgs_item_id', $editId);
			$this->db->update('ftgs_pr_items',$data);
        }
		//fetch ftgs items
		 public function fetch_ftgs($id)
		{
			 $condition = "ftgs_item_id =" . "'" . $id . "'";
			$this->db->select('*');
			$this->db->from('ftgs_pr_items');
			$this->db->where($condition);
			$query = $this->db->get();
			return $query->row();
		}
		
		//insert ftgs pr
		 public function insert_ftgs_pr($data) 
		 {
			$this->load->database();
			$this->db->insert('ftgs_pr_master', $data);
		}
		//insert file attachment
		public function file_insert($datanew) 
		 {
			$this->load->database();
			$this->db->insert('ftgs_pr_attachment', $datanew);
		}
		//update pr ftgs pr id
		public function update_item_withftgs($new_id,$old_id)  
      {  
	  
	   $this->db->where('ftgs_pr_id', $old_id);
       $this->db->update('ftgs_pr_items',$new_id);
         
      }  
	  //fetch draft ftgs 
		 public function fetchdraftFTGSpr($emp_code)
		{
			$condition = "ftgs_pr_status=0 and ftgs_pr_owner_code =" . "'" . $emp_code . "'";
			$this->db->select('*');
			$this->db->from('ftgs_pr_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//fetch pending ftgs 
		 public function fetchPendingFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and pm.ftgs_pr_status=1 and ag.action=0 and ag.emp_code =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//fetch PH pending ftgs 
		 public function ph_fetchPendingFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=0 and ag.level_of=1 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//fetch ftgs pr details 
		 public function ftgsPrDetails($ftgs_pr_id)
		{
			$condition = "ftgs_pr_id =" . "'" . $ftgs_pr_id . "'";
			$this->db->select('*');
			$this->db->from('ftgs_pr_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//fetch upload attachment details 
		 public function fetchuploadattach($ftgs_pr_id)
		{
			$condition = "ftgs_pr_id =" . "'" . $ftgs_pr_id . "'";
			$this->db->select('*');
			$this->db->from('ftgs_pr_attachment');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//edit ftgs item draft
		 public function drftupdate_item_ftgs($data, $editId) 
		 {
			$this->db->where('ftgs_item_id', $editId);
			$this->db->update('ftgs_pr_items',$data);
        }
		//insert ftgs item draft
		 public function draft_add_ftgs_pr($data) 
		 {
			$this->load->database();
			$this->db->insert('ftgs_pr_items', $data);
		}
		//insert action grid
		 public function authorityone($dataauth) 
		 {
			$this->load->database();
			$this->db->insert('ftgs_action_grid', $dataauth);
		}
		 public function updatedraft($id,$data)  
      {  
	  
	   $this->db->where('ftgs_pr_id', $id);
       $this->db->update('ftgs_pr_master',$data);
         
      } 
	  
	  //fetch auth ID
	  
		public function fetchReportingDetails($plant_code) 
		{
			$condition = "auth_level=1 and CURDATE() between auth_fromDate and auth_ToDate and plant_code =" . "'" . $plant_code . "'";
			 //plant_code = 1001 AND auth_level = 1
			$this->db->select('auth_id');
			$this->db->from('ftgs_reporting_grid');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->auth_id;
			} else {
				return false;
			}
		}
		//reject ftgs pr tbl
		
      public function fetchrejectTBL($emp_code) 
	  {
        $condition = "ftgs_pr_status=2 AND ftgs_pr_owner_code=" . "'" . $emp_code . "'";
        $this->db->select('*');
        $this->db->from('ftgs_pr_master');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
	//ph reject ftgs pr tbl
		
      public function ph_fetchrejectTBL($emp_code) 
	  {
        $condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.action=2 and ag.level_of=1 and ag.emp_code=em.emp_code and ag.action_autho =" . "'" . $emp_code . "'";
		$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
		$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
	//fetch approval table
	 public function fetchFTGSapprovalTbl($emp_code) {
        $condition = "ftgs_pr_status=3 AND ftgs_pr_owner_code=" . "'" . $emp_code . "'";
        $this->db->select('*');
        $this->db->from('ftgs_pr_master');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
	//ph fetch approval table
	 public function phfetchFTGSapprovalTbl($emp_code) {
        $condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.action=1 and ag.level_of=1 and ag.emp_code=em.emp_code and ag.action_autho =" . "'" . $emp_code . "'";
		$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
		$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
	public function fetch_dh_name($emp_id) 
	{
		$condition = "emp_code =" . "'" . $emp_id . "'";
		$this->db->select('emp_name');
		$this->db->from('employee_master');
		$this->db->where($condition);
		$query = $this->db->get();
		if ($query->num_rows() >= 1) {
			return $query->row()->emp_name;
		} 
		else {
			return false;
		}
	}
	public function fetch_ph_id($del_loc) 
	{
		$condition = "plant_code =" . "'" . $del_loc . "'";
		$this->db->select('ph_id');
		$this->db->from('plant_master');
		$this->db->where($condition);
		$query = $this->db->get();

			if ($query->num_rows() >= 1) {
				return $query->row()->ph_id;
		} else {
		return false;
		}
	}
	//fetch local_rim_id 
	public function ftgsDetailsHodActionData($emp_code,$ftgs_pr_id) 
	{
      $sql = "SELECT action_grid_id FROM ftgs_action_grid WHERE action_autho=".$emp_code." and ftgs_pr_id=".$ftgs_pr_id." and action=0 and level_of=1 ORDER BY action_grid_id DESC LIMIT 0, 1" ;
      $query = $this->db->query($sql);
      if ($query->num_rows() >= 1) 
	  {
            return $query;
      } 
	  else 
		{
           return false;
       }
    }
	public function getUserDetails($ftgs_pr_id) {

        $condition = "ftgs_pr_id =" . "'" . $ftgs_pr_id . "'";
        $this->db->select('ftgs_pr_owner_code as user');
        $this->db->from('ftgs_pr_master');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->user;
        } else {
            return false;
        }
    }
	//fetch sanction ID
	  
		public function fetchSanctionDetails($plant_code) 
		{
			$condition = "auth_level=2 and CURDATE() between auth_fromDate and auth_ToDate and plant_code =" . "'" . $plant_code . "'";
			 //plant_code = 1001 AND auth_level = 1
			$this->db->select('auth_id');
			$this->db->from('ftgs_reporting_grid');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->auth_id;
			} else {
				return false;
			}
		}
		 public function updateuserAction($data, $editId,$Ftgs_action_id) 
		 {
			$condition = "ftgs_pr_id=" . "'" . $editId . "' and action_grid_id=" . "'" . $Ftgs_action_id ."'";
			$this->db->where($condition);
			$this->db->update('ftgs_action_grid',$data);
        }
		public function updatesanAction($data, $editId,$Ftgs_action_id) 
		 {
			$condition = "ftgs_pr_id=" . "'" . $editId . "' and action_grid_id=" . "'" . $Ftgs_action_id ."'";
			$this->db->where($condition);
			$this->db->update('ftgs_action_grid',$data);
        }
		public function ftgsProcessRepAutho($data2) {
        $this->load->database();
        $this->db->insert('ftgs_action_grid', $data2);
        }
		public function ftgsProcessSancAutho($data2) {
        $this->load->database();
        $this->db->insert('ftgs_action_grid', $data2);
        }
		
		///PLANT HEAD......
		//fetch plant pending ftgs 
		 public function plant_fetchPendingFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=0 and ag.level_of=2 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//fetch plant reject ftgs 
		 public function plant_fetchRejectFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=2 and ag.level_of=2 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//fetch plant reject ftgs 
		 public function plant_fetchplantFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=1 and ag.level_of=2 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//fetch sanction ID
	  
		public function getSanctionAuthoDetails() 
		{
			$condition = "auth_level=3 and CURDATE() between auth_fromDate and auth_ToDate";
			 //plant_code = 1001 AND auth_level = 1
			$this->db->select('auth_id');
			$this->db->from('ftgs_reporting_grid');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->auth_id;
			} else {
				return false;
			}
		}
		//fetch sanc level
	public function ftgsDetailsSancActionData($emp_code,$ftgs_pr_id) 
	{
      $sql = "SELECT action_grid_id FROM ftgs_action_grid WHERE action_autho=".$emp_code." and ftgs_pr_id=".$ftgs_pr_id." and action=0 and level_of=2 ORDER BY action_grid_id DESC LIMIT 0, 1" ;
      $query = $this->db->query($sql);
      if ($query->num_rows() >= 1) 
	  {
            return $query;
      } 
	  else 
		{
           return false;
       }
    }
	//ITEM CODE fetch data pendding table
		 public function ICfetchPendingFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=0 and ag.level_of=3 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//ITEM CODE fetch data Reject table
		 public function ICfetchRejectFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=2 and ag.level_of=3 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//ITEM CODE fetch data Approved table
		 public function ICfetchApproveFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=1 and ag.level_of=3 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		public function getItemCodeAuthoDetails() 
		{
			$condition = "auth_level=4 and CURDATE() between auth_fromDate and auth_ToDate";
			 //plant_code = 1001 AND auth_level = 1
			$this->db->select('auth_id');
			$this->db->from('ftgs_reporting_grid');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->auth_id;
			} else {
				return false;
			}
		}
		//fetch sanc level
		public function ftgsItemCodeAction($emp_code,$ftgs_pr_id) 
		{
			$sql = "SELECT action_grid_id FROM ftgs_action_grid WHERE action_autho=".$emp_code." and ftgs_pr_id=".$ftgs_pr_id." and action=0 and level_of=3 ORDER BY action_grid_id DESC LIMIT 0, 1" ;
			$query = $this->db->query($sql);
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}	
		}
		
		
		//ION============
		//ION fetch data pendding table
		 public function IONfetchPendingFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=0 and ag.level_of=4 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//ION fetch data Reject table
		 public function IONfetchrejectFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=2 and ag.level_of=4 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//ION fetch data approve table
		 public function IONfetchapproveDetails($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=1 and ag.level_of=4 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		public function getIONAuthoDetails() 
		{
			$condition = "auth_level=5 and CURDATE() between auth_fromDate and auth_ToDate";
			$this->db->select('auth_id');
			$this->db->from('ftgs_reporting_grid');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->auth_id;
			} else {
				return false;
			}
		}
		//fetch ION Autho level
		public function ftgsIONAction($emp_code,$ftgs_pr_id) 
		{
			$sql = "SELECT action_grid_id FROM ftgs_action_grid WHERE action_autho=".$emp_code." and ftgs_pr_id=".$ftgs_pr_id." and action=0 and level_of=4 ORDER BY action_grid_id DESC LIMIT 0, 1" ;
			$query = $this->db->query($sql);
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}	
		}
		
		//Asset Code ==========
		public function ACCfetchPendingFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=0 and ag.level_of=5 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		public function getACCAuthoDetails() 
		{
			$condition = "auth_level=6 and CURDATE() between auth_fromDate and auth_ToDate";
			$this->db->select('auth_id');
			$this->db->from('ftgs_reporting_grid');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->auth_id;
			} else {
				return false;
			}
		}
		//fetch Asset Autho level
		public function ftgsACCAction($emp_code,$ftgs_pr_id) 
		{
			$sql = "SELECT action_grid_id FROM ftgs_action_grid WHERE action_autho=".$emp_code." and ftgs_pr_id=".$ftgs_pr_id." and action=0 and level_of=5 ORDER BY action_grid_id DESC LIMIT 0, 1" ;
			$query = $this->db->query($sql);
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}	
		}
		//Asset code fetch data Reject table
		 public function ACCfetchrejectFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=2 and ag.level_of=5 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//Asset code fetch data approve table
		 public function ACCfetchapproveDetails($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=1 and ag.level_of=5 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		public function POfetchPendingFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=0 and ag.level_of=6 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}

	//PO fetch data Reject table
		 public function POfetchrejectFTGSpr($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=2 and ag.level_of=6 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//PO fetch data approve table
		 public function POfetchapproveDetails($emp_code)
		{
			$condition = "pm.ftgs_pr_id=ag.ftgs_pr_id and ag.emp_code=em.emp_code and ag.action=1 and ag.level_of=6 and ag.action_autho =" . "'" . $emp_code . "'";
			$this->db->select('pm.ftgs_pr_id,pm.ftgs_pr_date,pm.ftgs_pr_owner_name,pm.ftgs_delivary_loc,pm.ftgs_procurement_res,ag.action,pm.ftgs_pr_status');
			$this->db->from('ftgs_pr_master pm,ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
		//fetch IO Autho level
		public function ftgsIOAction($emp_code,$ftgs_pr_id) 
		{
			$sql = "SELECT action_grid_id FROM ftgs_action_grid WHERE action_autho=".$emp_code." and ftgs_pr_id=".$ftgs_pr_id." and action=0 and level_of=6 ORDER BY action_grid_id DESC LIMIT 0, 1" ;
			$query = $this->db->query($sql);
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}	
		}
		
		 public function deptAuthNavBarStatus($emp_code) 
		 {
		$condition = "auth_status=1 and auth_level=1 and auth_id  =" . "'" . $emp_code . "'";
        $this->db->select('auth_id');
        $this->db->from('ftgs_reporting_grid');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->auth_id;
        } else {
            return false;
        }
    }
	public function plantAuthNavBarStatus($emp_code) 
		 {
		$condition = "auth_status=1 and auth_level=2 and auth_id  =" . "'" . $emp_code . "'";
        $this->db->select('auth_id');
        $this->db->from('ftgs_reporting_grid');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->auth_id;
        } else {
            return false;
        }
    }
	public function ItemCodeAuthNavBarStatus($emp_code) 
	{
		$condition = "auth_status=1 and auth_level=3 and auth_id  =" . "'" . $emp_code . "'";
        $this->db->select('auth_id');
        $this->db->from('ftgs_reporting_grid');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) 
		{
            return $query->row()->auth_id;
        } 
		else 
		{
            return false;
        }
    }
	public function IONCreateAuthNavBarStatus($emp_code) 
	{
		$condition = "auth_status=1 and auth_level=4 and auth_id  =" . "'" . $emp_code . "'";
        $this->db->select('auth_id');
        $this->db->from('ftgs_reporting_grid');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) 
		{
            return $query->row()->auth_id;
        } 
		else 
		{
            return false;
        }
    }
	public function AssetCodeAuthNavBarStatus($emp_code) 
	{
		$condition = "auth_status=1 and auth_level=5 and auth_id  =" . "'" . $emp_code . "'";
        $this->db->select('auth_id');
        $this->db->from('ftgs_reporting_grid');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) 
		{
            return $query->row()->auth_id;
        } 
		else 
		{
            return false;
        }
    }
	public function POCreationAuthNavBarStatus($emp_code) 
	{
		$condition = "auth_status=1 and auth_level=6 and auth_id  =" . "'" . $emp_code . "'";
        $this->db->select('auth_id');
        $this->db->from('ftgs_reporting_grid');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) 
		{
            return $query->row()->auth_id;
        } 
		else 
		{
            return false;
        }
    }
	public function approval_status($ftgs_pr_id) 
	{
		$condition = "em.emp_code=frg.auth_id AND frg.auth_id=fag.action_autho AND fag.ftgs_pr_id=fpm.ftgs_pr_id AND fpm.ftgs_pr_id=" . "'" . $ftgs_pr_id . "' GROUP BY fag.action_grid_id ORDER BY `fag`.`action_grid_id` ASC";
        $this->db->select('em.emp_code, em.emp_name,fpm.ftgs_pr_id,fpm.ftgs_pr_status,frg.auth_level,fag.action,fag.comment,fag.action_date,fag.action_time, fag.action_grid_id');
        $this->db->from('employee_master em,ftgs_pr_master fpm,ftgs_reporting_grid frg,ftgs_action_grid fag');
        $this->db->where($condition);
        $query = $this->db->get();
       if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
	}
		public function ftgs_item_list($ftgs_pr_id) {
			$condition = "ftgs_pr_id =" . "'" . $ftgs_pr_id . "' ";
			$this->db->select('*');
			$this->db->from('ftgs_pr_items');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query;
			}
			else {
				return false;
			}
		}
	 public function File_update($id,$data){
		
		$this->db->where('ftgs_pr_id',$id);
	   $this->db->update('ftgs_pr_master',$data);
	   
	    
}
	//fetch upload attachment details 
		 public function fetchAssetAttach($ftgs_pr_id)
		{
			$condition = "ftgs_pr_id =" . "'" . $ftgs_pr_id . "'";
			$this->db->select('*');
			$this->db->from('ftgs_pr_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) 
			{
				return $query;
			} 
			else 
			{
				return false;
			}
				return $query->row();
		}
        	//fetch email Dept Head
		public function fetchDHMailDetails($DHCode) 
		{
			$condition = "emp_code =" . "'" . $DHCode . "'";
			$this->db->select('emp_email As dhEmail');
			$this->db->from('employee_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->dhEmail;
			} else {
				return false;
			}
		}
        
        
        	//fetch email Plant Head
		public function fetchPHMailDetails($IOCode) 
		{
			$condition = "emp_code =" . "'" . $IOCode . "'";
			$this->db->select('emp_email As PhEmail');
			$this->db->from('employee_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->PhEmail;
			} else {
				return false;
			}
		}
		//fetch email ItemCode Head
		public function fetchItemCodeMailDetails($ICCode) 
		{
			$condition = "emp_code =" . "'" . $ICCode . "'";
			$this->db->select('emp_email As itemCodeEmail');
			$this->db->from('employee_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->itemCodeEmail;
			} else {
				return false;
			}
		}
		//fetch email ION Head
		public function fetchIONMailDetails($IONCode) 
		{
			$condition = "emp_code =" . "'" . $IONCode . "'";
			$this->db->select('emp_email As IONEmail');
			$this->db->from('employee_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->IONEmail;
			} else {
				return false;
			}
		}
		//fetch email Asset Head
		public function fetchAssetMailDetails($ACCCode) 
		{
			$condition = "emp_code =" . "'" . $ACCCode . "'";
			$this->db->select('emp_email As AssetEmail');
			$this->db->from('employee_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->AssetEmail;
			} else {
				return false;
			}
		}
		//fetch email PO Head
		public function fetchPoCreateMailDetails($emp_code) 
		{
			$condition = "ag.action_autho=em.emp_code and ag.level_of=6  and ag.emp_code =" . "'" . $emp_code . "'";
			$this->db->select('em.emp_email As POCreateEmail');
			$this->db->from('ftgs_action_grid ag,employee_master em');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->POCreateEmail;
			} else {
				return false;
			}
		}
		//fetch email User
		 public function fetchUserMailDetails($ftgs_pr_id) {
        $condition = "em.emp_code=fpm.ftgs_pr_owner_code and ftgs_pr_id =" . "'" . $ftgs_pr_id . "'";
        $this->db->select('em.emp_email');
        $this->db->from('ftgs_pr_master fpm,employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->emp_email;
        } else {
            return false;
        }
    }
		//fetch User Name
		public function fetchEmpNameMailDetails($emp_code) 
		{
			$condition = "emp_code=" . "'" . $emp_code . "'";
			$this->db->select('emp_Name As emp_Name');
			$this->db->from('employee_master');
			$this->db->where($condition);
			$query = $this->db->get();
			if ($query->num_rows() >= 1) {
				return $query->row()->emp_Name;
			} else {
				return false;
			}
		}
		//fetch User Plant
		public function getUserPlant($ftgs_pr_id) {

        $condition = "ftgs_pr_id =" . "'" . $ftgs_pr_id . "'";
        $this->db->select('ftgs_plant_code as UserPlant');
        $this->db->from('ftgs_pr_master');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->UserPlant;
        } else {
            return false;
        }
    }
	//fetch User Department
	public function getUserDept($emp_dept) {

        $condition = "dept_code =" . "'" . $emp_dept . "'";
        $this->db->select('dept_name as UserDept');
        $this->db->from('department_master');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->UserDept;
        } else {
            return false;
        }
    }
}
	
?>