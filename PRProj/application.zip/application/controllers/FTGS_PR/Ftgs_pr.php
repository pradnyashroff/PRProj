<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Ftgs_pr extends CI_Controller 
	{
		
		public function __construct() 
		{
			parent::__construct();
			$this->load->helper('form');
			$this->load->library('form_validation');
			$this->load->library('session');
			$this->load->model('login_database');
			$this->method_call =& get_instance();
			
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
		}
		
		//create ftgs pr
		public function create_Pr() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/create_FTGS_pr');
        }
		//draft tbl ftgs pr
		public function draftTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/draft_FTGS_pr_tbl');
        }
		//draft tbl ftgs pr
		public function draftFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/draft_FTGS_pr_view',$data);
        }
		//pendding tbl ftgs pr
		public function penddingTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/pendding_FTGS_pr_tbl');
        }
		//pendding view ftgs pr
		public function penddingFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/pendding_FTGS_pr_view',$data);
        }
		//Reject tbl ftgs pr
		public function rejectTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/reject_FTGS_pr_tbl');
        }
		//Reject view ftgs pr
		public function rejectFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/reject_FTGS_pr_view',$data);
        }
		//approval tbl ftgs pr
		public function approvalTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/approval_FTGS_pr_tbl');
        }
		//Approved view ftgs pr
		public function approvalFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/approval_FTGS_pr_view',$data);
        }
		//PH pendding tbl ftgs pr
		public function ph_penddingTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/PH_pendding_FTGS_pr_tbl');
        }
		//PH pendding view ftgs pr
		public function ph_penddingFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/PH_pendding_FTGS_pr_view',$data);
        }
		//PH Reject tbl ftgs pr
		public function ph_rejectTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/PH_reject_FTGS_pr_tbl');
        }
		//PH Reject view ftgs pr
		public function ph_rejectFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/PH_reject_FTGS_pr_view',$data);
        }
		//PH approval tbl ftgs pr
		public function ph_approvalTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/PH_approval_FTGS_pr_tbl');
        }
		//PH Approved view ftgs pr
		public function ph_approvalFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/PH_approval_FTGS_pr_view',$data);
        }
		//profile fetch
		public function profile_pic($emp_code)
		{
			
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model');  
			$data['profile']=$this->ftgs_model->profile_fetch($emp_code);  
		  	return  $data['profile'];
		}
		//pr type 
		public function pr_type()
		{
			
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model');  
			$data['pr_type']=$this->ftgs_model->pr_type();  
		  	return  $data['pr_type'];
		}
		//list plant
		public function plant()
		{
			
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model');  
			$data['plant']=$this->ftgs_model->plant();  
		  	return  $data['plant'];
		}
		//fetch Department
		public function department($emp_dept)
		{
			
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model');  
			$data['dept_name']=$this->ftgs_model->department($emp_dept);  
		  	return  $data;
		}
		//fetch ftgs pr items
		public function ftgs_item($emp_code)
		{
			
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model');  
			$data['item']=$this->ftgs_model->ftgs_item($emp_code);  
		  	return $data['item'];
		}
		//add ftgs items
		public function add_item_ftgs()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$data = array(
                'ftgs_pr_id' => $this->input->post('txt_temp_ftgs_id'),
                'ftgs_item_code' => $this->input->post('txt_item_code'),
                'ftgs_item_description' => $this->input->post('txt_description'),
                'ftgs_req_qty' => $this->input->post('txt_reqr_quntity'),
                'ftgs_uom' => $this->input->post('txt_uom'),
                'ftgs_approx_rate' => $this->input->post('txt_approx_rate'),
                'ftgs_approx_total_amt' => $this->input->post('txt_apporox_amt'),
				'ftgs_expected_delivery' => $this->input->post('txt_delivary_period'),
				'ftgs_project_detail' => $this->input->post('txt_project_details'),
				'ftgs_technical_detail' => $this->input->post('txt_mfg_nm'),
				'ftgs_cust_code' => $this->input->post('txt_cust_cost'),
				'ftgs_sales_material' => $this->input->post('txt_sales_meterial'),
				'ftgs_ecn_new' => $this->input->post('txt_ecn_new'),
				'ftgs_ecn_newcode' => $this->input->post('txt_ecn_newcode'),
                'ftgs_reg_date' => $date,
                'ftgs_reg_time' => $time,
                'ftgs_reg_by' => $this->input->post('txt_temp_ftgs_id')
            );
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
			$this->ftgs_model->add_ftgs_pr($data);
			$this->load->helper('url');
			$this->load->view('FTGSPR/create_FTGS_pr');
		
		}
		//update ftgs items
		public function update_item_ftgs()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$editId = $this->input->post('edit_item_id');
			
			$data = array(
                'ftgs_item_code' => $this->input->post('edit_item_code'),
                'ftgs_item_description' => $this->input->post('edit_description'),
                'ftgs_req_qty' => $this->input->post('edit_reqri_quntity'),
                'ftgs_uom' => $this->input->post('edit_uom'),
                'ftgs_approx_rate' => $this->input->post('edit_approx_rate'),
                'ftgs_approx_total_amt' => $this->input->post('edit_apporox_amt'),
				'ftgs_expected_delivery' => $this->input->post('edit_delivary_period'),
				'ftgs_project_detail' => $this->input->post('edit_project_details'),
				'ftgs_technical_detail' => $this->input->post('edit_mfg_nm'),
				'ftgs_cust_code' => $this->input->post('edit_cust_cost'),
				'ftgs_sales_material' => $this->input->post('edit_sales_meterial'),
				'ftgs_ecn_new' => $this->input->post('edit_ecn_new'),
				'ftgs_ecn_newcode' => $this->input->post('edit_ecn_newcode'),
                'ftgs_reg_date' => $date,
                'ftgs_reg_time' => $time,
                'ftgs_reg_by' => $this->input->post('edit_ftgs_emp')
            );
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
			$this->ftgs_model->update_ftgs_pr($data, $editId);
			$this->load->helper('url');
			$this->load->view('FTGSPR/create_FTGS_pr');
		
		}
		//update ftgs items code
		public function update_itemCode()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$editId = $this->input->post('edit_item_id');
			$data = array(
                'ftgs_item_code' => $this->input->post('edit_item_code'),
            );
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
			$this->ftgs_model->update_itemCode($data, $editId);
			$this->load->helper('url');
			echo '<script>window.history.back();</script>';
		
		}
		//add draft ftgs items
		public function draft_add_item_ftgs()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			 $temp_pr=$this->input->post('draft_temp_ftgs_id');
			$data = array(
                'ftgs_pr_id' => $temp_pr,
                'ftgs_item_code' => $this->input->post('draft_item_code'),
                'ftgs_item_description' => $this->input->post('draft_description'),
                'ftgs_req_qty' => $this->input->post('draft_reqr_quntity'),
                'ftgs_uom' => $this->input->post('draft_uom'),
                'ftgs_approx_rate' => $this->input->post('draft_approx_rate'),
                'ftgs_approx_total_amt' => $this->input->post('draft_apporox_amt'),
				'ftgs_expected_delivery' => $this->input->post('draft_delivary_period'),
				'ftgs_project_detail' => $this->input->post('draft_project_details'),
				'ftgs_technical_detail' => $this->input->post('draft_mfg_nm'),
				'ftgs_cust_code' => $this->input->post('draft_cust_cost'),
				'ftgs_sales_material' => $this->input->post('draft_sales_meterial'),
				'ftgs_ecn_new' => $this->input->post('draft_ecn_ne'),
				'ftgs_ecn_newcode' => $this->input->post('draft_ecn_newcode'),
                'ftgs_reg_date' => $date,
                'ftgs_reg_time' => $time,
                'ftgs_reg_by' => $this->input->post('draft_temp_ftgs_id')
            );
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model');
			$result=$this->ftgs_model->draft_add_ftgs_pr($data);
			$this->load->helper('url');
			$data['ftgs_pr_id']=$temp_pr;
			$this->load->helper('url');
			echo '<script>window.history.back();</script>';
				
		}
		//update draft ftgs
		public function drftupdate_item_ftgs() 
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$editId = $this->input->post('editdrft_item_id');
			$data = array(
				'ftgs_item_code' => $this->input->post('editdrft_item_code'),
				'ftgs_item_description' => $this->input->post('editdrft_description'),
				'ftgs_req_qty' => $this->input->post('editdrft_reqri_quntity'),
				'ftgs_uom' => $this->input->post('editdrft_uom'),
				'ftgs_approx_rate' => $this->input->post('editdrft_approx_rate'),
				'ftgs_approx_total_amt' => $this->input->post('editdrft_apporox_amt'),
				'ftgs_expected_delivery' => $this->input->post('editdrft_delivary_period'),
				'ftgs_project_detail' => $this->input->post('editdrft_project_details'),
				'ftgs_technical_detail' => $this->input->post('editdrft_mfg_nm'),
				'ftgs_cust_code' => $this->input->post('editdrft_cust_cost'),
				'ftgs_sales_material' => $this->input->post('editdrft_sales_meterial'),
				'ftgs_ecn_new' => $this->input->post('editdrft_ecn_new'),
				'ftgs_ecn_newcode' => $this->input->post('editdrft_ecn_newcode'),
				'ftgs_reg_date' => $date,
				'ftgs_reg_time' => $time
				
				
            );
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
			$this->ftgs_model->drftupdate_item_ftgs($data,$editId);
			$this->load->helper('url');
			echo '<script>window.history.back();</script>';
			
			//$this->load->view('FTGSPR/draft_FTGS_pr_view',$data);
		}

		//inser ftgs ftgs items
		public function insert_ftgs_pr()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$data = array(
               'ftgs_plant_code' => $this->input->post('txt_plant'),
                'ftgs_pr_date' => $date,
                'ftgs_pr_type' => $this->input->post('txt_pr_type'),
                'ftgs_pr_owner_code' => $this->input->post('txt_pr_owner_code'),
                'ftgs_pr_owner_name' => $this->input->post('txt_pr_owner'),
                'ftgs_dept_id' => $this->input->post('txt_dept_id'),
				'ftgs_delivary_loc' => $this->input->post('txt_location'),
				'ftgs_inspection_req' => $this->input->post('txt_supplier'),
				'ftgs_budget_consider' => $this->input->post('txt_conside_budge'),
				'ftgs_procurement_res' => $this->input->post('txt_reson'),
				'ftgs_ion_no' => $this->input->post('txt_ion_no'),
				'ftgs_cust_cost_upfront' => $this->input->post('txt_cust_cost_upfront'),
				'ftgs_cust_cost_amortization' => $this->input->post('txt_cust_cost_amort'),
				'ftgs_own_investment' => $this->input->post('txt_own_inve'),
				'ftgs_draft_date' => $date,
                'ftgs_reg_time' => $time,
                'ftgs_reg_by' => $this->input->post('txt_emp_code')
				
            );
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
			$this->ftgs_model->insert_ftgs_pr($data);
			$row = $this->db->query('SELECT MAX(ftgs_pr_id) AS `maxid` FROM `ftgs_pr_master`')->row();
			if ($row) 
			{
				$ftgs_pr_id=$row->maxid;
				
			}
			$old_id=$this->input->post('txt_emp_code');
			$new_id = array(
				'ftgs_pr_id' => $ftgs_pr_id,
			);
			 $this->ftgs_model->update_item_withftgs($new_id,$old_id);
			
			//upload file insert
			if (!empty($_FILES['upload_file']['name'][0])) 
			{
                if ($this->upload_files($_FILES['upload_file']['name'], $_FILES['upload_file'], $ftgs_pr_id) === FALSE) 
				{
                    $data['error'] = $this->upload->display_errors('<div class="alert alert-danger">', '</div>');
					?>
					<script type="text/javascript">
						alert("Your Files Uploaded Successfully");
					</script>
					<?php
				}
			}
			else
			{
			}
			?>
            <script type="text/javascript">
                 alert("Record Successfully inserted with PR ID <?php echo $ftgs_pr_id; ?>");
             </script> <?php
			 $this->load->helper('url');
			 $this->load->view('FTGSPR/draft_FTGS_pr_tbl',$new_id);
		}
		 private function upload_files($title, $files, $ftgs_pr_id)
		{
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
			chmod('./uploads/ftgs_pr/', 0777);
			$path   = './uploads/ftgs_pr/'.$ftgs_pr_id;
			if (!is_dir($path)) 
			{ 
				mkdir($path, 0777, TRUE);
			}
		   $config = array(
				'upload_path'   => $path,
				'allowed_types' => '*',
				'overwrite'     => 1,                       
			);
			$this->load->library('upload', $config);
			$images = array();
			foreach ($files['name'] as $key => $image)
			{
				$_FILES['images[]']['name']= $files['name'][$key];
				$_FILES['images[]']['type']= $files['type'][$key];
				$_FILES['images[]']['tmp_name']= $files['tmp_name'][$key];
				$_FILES['images[]']['error']= $files['error'][$key];
				$_FILES['images[]']['size']= $files['size'][$key];
				$fileName = $image;
				$images[] = $fileName;
				$config['file_name'] = $fileName;
				$this->upload->initialize($config);
				if ($this->upload->do_upload('images[]'))
				{
					$this->upload->data();
					date_default_timezone_set('Asia/Kolkata');
					$date = date('d-m-Y');
					$time = date("h:i A");
					$datanew = array(
						'ftgs_pr_id' => $ftgs_pr_id,
						'ftgs_file_name' => preg_replace('/\s+/', '_', $fileName),
						'ftgs_reg_date' => $date,
						'ftgs_reg_time' => $time,
						'ftgs_reg_by' => $this->input->post('txt_emp_code'),
						'ftgs_file_status' => 1
					);
					$this->load->database();  
					$this->load->model('Ftgs_PR/ftgs_model'); 
					$this->ftgs_model->file_insert($datanew);
				} 
				else 
				{
					return false;
				}
			}
			return $images;
		}	  
		//delete ftgs items
		public function deleteftgs() 
		{	
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model');
			$id = $this->input->get('id');
			$this->ftgs_model->deleteitem($id);
			?>
			<script>alert("Delete Successfully");</script>
			<?php
			$this->load->helper('url');
			echo '<script>window.history.back();</script>';
		}
		public function ftgs_edit($id) 
		{
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model');
			$data = $this->ftgs_model->fetch_ftgs($id);
			echo json_encode($data);
		}
		
		 //fetch draft ftgs 
		public function draftTBLfetch($emp_code) 
		{
			$this->load->helper('url');
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
			$data['claimList'] = $this->ftgs_model->fetchdraftftgspr($emp_code);
			return $data['claimList'];
			
		}
		//draft table
		function fetchDraftDetails($emp_code) {
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('Ftgs_PR/ftgs_model');
        $data['draftList'] = $this->ftgs_model->fetchdraftFTGSpr($emp_code);
        return $data['draftList'];
    }
	//pendding table
	function fetchpenddingDetails($emp_code) {
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('Ftgs_PR/ftgs_model');
        $data['pendingList'] = $this->ftgs_model->fetchPendingFTGSpr($emp_code);
        return $data['pendingList'];
    }
	//PH pendding table
	function ph_fetchpenddingDetails($emp_code) {
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('Ftgs_PR/ftgs_model');
        $data['pendingList'] = $this->ftgs_model->ph_fetchPendingFTGSpr($emp_code);
        return $data['pendingList'];
    }
	//fetch ftgs pr details
		function ftgsprDetails($ftgs_pr_id) {
		$this->load->helper('url');
        $this->load->database();
        $this->load->model('Ftgs_PR/ftgs_model');
        $data['ftgsprdetails'] = $this->ftgs_model->ftgsPrDetails($ftgs_pr_id);
        return $data['ftgsprdetails'];
    }
	//fetch upload attachment ftgs 
		public function fetchupload($ftgs_pr_id) 
		{
			$this->load->helper('url');
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
			$data['filefetch'] = $this->ftgs_model->fetchuploadattach($ftgs_pr_id);
			return $data['filefetch'];
			
		}
		//delete for draft gtgs pr
		public function deleteftgsData($id) {
			$this->load->helper('url');
			$this->load->database();
			$this->db->query("delete from ftgs_pr_items where ftgs_item_id='" . $id . "'");
		}
		
		//update data draft
		
		public function draft_insert_ftgs_pr()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$pr_status=$this->input->post('rdo_ftgs_status');
			$pr_emp_code=$this->input->post('txt_emp_code');
			$FTGSpr_no=$this->input->post('txtftgsId');
			if($pr_status==1)
			{
				$data = array(
				'ftgs_plant_code' => $this->input->post('draft_plant'),
				'ftgs_delivary_loc' => $this->input->post('draft_location'),
				'ftgs_inspection_req' => $this->input->post('draft_supplier'),
				'ftgs_budget_consider' => $this->input->post('draft_conside_budge'),
				'ftgs_procurement_res' => $this->input->post('draft_reson'),
				'ftgs_ion_no' => $this->input->post('draft_ion_no'),
				'ftgs_cust_cost_upfront' => $this->input->post('draft_cust_cost_upfront'),
				'ftgs_cust_cost_amortization' => $this->input->post('draft_cust_cost_amort'),
				'ftgs_own_investment' => $this->input->post('draft_own_inve'),
				'ftgs_draft_date' => $date,
				'ftgs_pr_status' => 1
              
				);
				$draft_pr_id=$this->input->post('draft_pr_no');
				$this->ftgs_model->updatedraft($draft_pr_id,$data);
				$dataauth = array(
				'ftgs_pr_id' => $draft_pr_id,
				'emp_code' => $pr_emp_code,
				'action_autho' => $this->input->post('authIDLevel1'),
				'level_of' => 1,
				'action' => 0,
				'action_date' => $date,
				'action_time' => $time
                );
					
				$this->load->model('Ftgs_PR/ftgs_model'); 
				$this->ftgs_model->authorityone($dataauth);
				// Email Code Start-
					$reciver= $this->input->post('txtDHAuthoEmail');
					
					$ccuser=$this->input->post('txtUserAuthoEmail');
					$subject='New Interplant FTGS PR Created By '.$this->input->post('txtEmpNameEmail').' Against FTGS PR NO.  '.$FTGSpr_no.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$FTGSpr_no.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$date. '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Reason:</b>  '.$this->input->post('draft_reson').'</li>
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
					
				$this->load->helper('url');
				$this->load->view('FTGSPR/draft_FTGS_pr_tbl');
			}
			else{
				$data = array(
				'ftgs_plant_code' => $this->input->post('draft_plant'),
				'ftgs_delivary_loc' => $this->input->post('draft_location'),
				'ftgs_inspection_req' => $this->input->post('draft_supplier'),
				'ftgs_budget_consider' => $this->input->post('draft_conside_budge'),
				'ftgs_procurement_res' => $this->input->post('draft_reson'),
				'ftgs_ion_no' => $this->input->post('draft_ion_no'),
				'ftgs_cust_cost_upfront' => $this->input->post('draft_cust_cost_upfront'),
				'ftgs_cust_cost_amortization' => $this->input->post('draft_cust_cost_amort'),
				'ftgs_own_investment' => $this->input->post('draft_own_inve'),
				'ftgs_draft_date' => $date,
               
				);

			
				$draft_pr_id=$this->input->post('draft_pr_no');
				$this->ftgs_model->updatedraft($draft_pr_id,$data);
				$this->load->helper('url');
				$this->load->view('FTGSPR/draft_FTGS_pr_tbl');
			}
							 if (!empty($_FILES['upload_file']['name'][0])) {
                if ($this->upload_files($_FILES['upload_file']['name'], $_FILES['upload_file'], $draft_pr_id) === FALSE) {
                    $data['error'] = $this->upload->display_errors('<div class="alert alert-danger">', '</div>');
				?>
                <script type="text/javascript">
                    alert("Your Files Uploaded Successfully");
                </script>
            <?php
					
                }
				
            }
		}
		
		//fetch auth ID
		function fetchReportingDetails($plant_code) 
		{
			$this->load->database();
			$data['auth_id'] = $this->ftgs_model->fetchReportingDetails($plant_code);
			return $data;
		}
		//reject fetch ftgs pr
		 function fetchRejectTBL($emp_code) 
		 {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['rejectList'] = $this->ftgs_model->fetchrejectTBL($emp_code);
			return $data['rejectList'];
		}
		//PH reject fetch ftgs pr
		 function phfetchRejectTBL($emp_code) 
		 {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['phrejectList'] = $this->ftgs_model->ph_fetchrejectTBL($emp_code);
			return $data['phrejectList'];
		}
		//reject view to draft
		public function ftgsRejectPR() 
		{
			$ftgsStatus = $this->input->post('rdo_ftgs_status');
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$UpdateId = $this->input->post('txtftgsId');
			if ($ftgsStatus == "draft") {
				$data = array(
				  'ftgs_draft_date' => $date,
				  'ftgs_reg_time' => $time,
				  'ftgs_pr_status'=>0,
				);
				$this->db->where('ftgs_pr_id', $UpdateId);
				$this->db->update('ftgs_pr_master', $data);
			}
			else 
			{
			   $message = "Ok! You have selected no action on FTGS PR";
			   echo "<script type='text/javascript'>alert('$message');</script>";
			}
			$this->load->helper('url');
			$this->load->view('FTGSPR/reject_FTGS_pr_tbl');
		}
		//fetch approav pr table
		function fetchFTGSApprovalTbl($emp_code) 
		{
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['approvedftgs'] = $this->ftgs_model->fetchFTGSapprovalTbl($emp_code);
			return $data['approvedftgs'];
		}
		//ph fetch approav pr table
		function phfetchFTGSApprovalTbl($emp_code) 
		{
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['phapprovedftgs'] = $this->ftgs_model->phfetchFTGSapprovalTbl($emp_code);
			return $data['phapprovedftgs'];
		}
		//Department name from dept_master
		 function fetch_ph_id($del_loc)
			{
				$this->load->database();  
				$this->load->model('Ftgs_PR/ftgs_model');
				$data['ph_id']=$this->ftgs_model->fetch_ph_id($del_loc);  		  		
				return  $data;
			} 
			//fetch local_rim_id 
		 function ftgsActionData($emp_code,$ftgs_pr_id) 
		 {
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['ftgsActionData'] = $this->ftgs_model->ftgsDetailsHodActionData($emp_code,$ftgs_pr_id);
			return $data['ftgsActionData'];
		}
		function getUserDetails($ftgs_pr_id) 
		{
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['user'] = $this->ftgs_model->getUserDetails($ftgs_pr_id);
			return $data;
		}
		public function upadatePend_insert_ftgs_pr()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$editId = $this->input->post('txtftgsId');
			$action = $this->input->post('ftgs_status');
			$Ftgs_action_id = $this->input->post('Ftgs_action_id');
			$phName = $this->input->post('txtPHName');
			if ($action == "1") {
            $data = array(
				'action_autho' => $this->input->post('txt_emp_code'),
				'action' => 1,
				'comment' => $this->input->post('txt_comment'),
				'action_date' => $date,
                'action_time' => $time
            );
            $data2 = array(
                'ftgs_pr_id' => $this->input->post('txtftgsId'),
                'emp_code' => $this->input->post('user_id'),
                'action_autho' => $this->input->post('sanc_code'),
                'level_of' => 2,
                'action' => 0,
                'action_date' => $date,
                'action_time' => $time
            );
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            $this->ftgs_model->ftgsProcessRepAutho($data2);
            
            	// Email Code Start-
					$reciver= $this->input->post('txtPHAuthoEmail');  //PH email
					
					$ccuser=$this->input->post('txtUserAuthoEmail');
					$subject='Interplant FTGS PR Approved By '.$phName.' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
            
		}
		else 
		{
            $data = array(
                'action_autho' => $this->input->post('txt_emp_code'),
                'action' => 2,
                'comment' => $this->input->post('txt_comment'),
                'action_date' => $date,
                'action_time' => $time,
            );
            $data1 = array(
                'ftgs_pr_status' => 2
            );
          
            $this->db->where('ftgs_pr_id', $editId);
            $this->db->update('ftgs_pr_master', $data1);
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            
            
            	// Email Code Start-
					//$reciver= $this->input->post('txtPHAuthoEmail');  //PH email
					$reciver= $this->input->post('txtUserAuthoEmail');
			
					$subject='Interplant FTGS PR Rejected By '.$phName.' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					//$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
         }
		 $this->load->helper('url');
		$this->load->view('FTGSPR/PH_pendding_FTGS_pr_tbl');
		
	}
	//fetch sanction ID
		function fetchsanctionDetails($plant_code) 
		{
			$this->load->database();
			$data['sanc_id'] = $this->ftgs_model->fetchSanctionDetails($plant_code);
			return $data;
		}
		
		
		//PLANT HEAD......
		
		//plant pendding tbl ftgs pr
		public function plant_penddingTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/plant_pendding_FTGS_pr_tbl');
        }
		
		//plant pendding table
		function plant_fetchpenddingDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['pendingList'] = $this->ftgs_model->plant_fetchPendingFTGSpr($emp_code);
			return $data['pendingList'];
		}
		//pendding view ftgs pr
		public function plantpenddingFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/plant_pendding_FTGS_pr_view',$data);
        }
		//plant Reject tbl ftgs pr
		public function plant_rejectTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/plant_reject_FTGS_pr_tbl');
        }
		//Reject view ftgs pr
		public function plantRejectFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/plant_reject_FTGS_pr_view',$data);
        }
		//plant Reject table
		function plant_fetchRejectDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['rejectList'] = $this->ftgs_model->plant_fetchRejectFTGSpr($emp_code);
			return $data['rejectList'];
		}
		//plant Approved tbl ftgs pr
		public function plant_approvTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/plant_approval_FTGS_pr_tbl');
        }
		//Reject Approved ftgs pr
		public function plantApproveFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/plant_approval_FTGS_pr_view',$data);
        }
		//plant Approved table
		function plant_fetchApproveDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['approveList'] = $this->ftgs_model->plant_fetchplantFTGSpr($emp_code);
			return $data['approveList'];
		}
		function getSanctionAuthoDetails() {
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('Ftgs_PR/ftgs_model');
        $data['autho_code'] = $this->ftgs_model->getSanctionAuthoDetails();
        return $data;
    }
	public function plantHead_insert_ftgs_pr()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$editId = $this->input->post('txtftgsId');
			$action = $this->input->post('ftgs_status');
			$Ftgs_action_id = $this->input->post('Ftgs_action_id');
			$plantName = $this->input->post('txtPHName');
			if ($action == "1") {
            $data = array(
				'action_autho' => $this->input->post('txt_emp_code'),
				'action' => 1,
				'comment' => $this->input->post('txt_comment'),
				'action_date' => $date,
                'action_time' => $time
            );
            $data2 = array(
                'ftgs_pr_id' => $this->input->post('txtftgsId'),
                'emp_code' => $this->input->post('user_id'),
                'action_autho' => $this->input->post('txt_plant_Autho'),
                'level_of' => 3,
                'action' => 0,
                'action_date' => $date,
                'action_time' => $time
            );
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            $this->ftgs_model->ftgsProcessRepAutho($data2);
            
            //email Code
                    $reciver= $this->input->post('txtPHAuthoEmail');  //PH email
					
					$ccuser=$this->input->post('txtUserAuthoEmail');
					$subject='Interplant FTGS PR Approved By '.$plantName.' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
            
		}
		else 
		{
            $data = array(
                'action_autho' => $this->input->post('txt_emp_code'),
                'action' => 2,
                'comment' => $this->input->post('txt_comment'),
                'action_date' => $date,
                'action_time' => $time,
            );
            $data1 = array(
                'ftgs_pr_status' => 2
            );
          
            $this->db->where('ftgs_pr_id', $editId);
            $this->db->update('ftgs_pr_master', $data1);
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            
            // Email Code Start-
					//$reciver= $this->input->post('txtPHAuthoEmail');  //PH email
					$reciver= $this->input->post('txtUserAuthoEmail');
			
					$subject='Interplant FTGS PR Rejected By '.$plantName.' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					//$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
         }
		 $this->load->helper('url');
		$this->load->view('FTGSPR/plant_pendding_FTGS_pr_tbl');
		
	}
	//fetch sanction level
		 function ftgsSancActionData($emp_code,$ftgs_pr_id) 
		 {
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['ftgsActionData'] = $this->ftgs_model->ftgsDetailsSancActionData($emp_code,$ftgs_pr_id);
			return $data['ftgsActionData'];
		}
		
		
		
		// ITEM CODE ................
		//ITEM CODE  pendding tbl ftgs pr
		public function IC_penddingTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/IC_pendding_FTGS_pr_tbl');
        }
		//ITEM CODE pendding view ftgs pr
		public function ICpenddingFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/IC_pendding_FTGS_pr_view',$data);
        }
		//ITEM CODE fetch data pendding table
		function ICfetchpenddingDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['pendingList'] = $this->ftgs_model->ICfetchPendingFTGSpr($emp_code);
			return $data['pendingList'];
		}
		//ITEM CODE  Reject tbl ftgs pr
		public function ICrejectTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/IC_reject_FTGS_pr_tbl');
        }
		//ITEM CODE Reject view ftgs pr
		public function ICrejectFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/IC_FTGS_pr_view',$data);
        }
		//ITEM CODE fetch data Reject table
		function ICfetchRejectDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['RejectList'] = $this->ftgs_model->ICfetchRejectFTGSpr($emp_code);
			return $data['RejectList'];
		}
		//ITEM CODE  Approved tbl ftgs pr
		public function ICapproveTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/IC_approval_FTGS_pr_tbl');
        }
		//ITEM CODE Approved view ftgs pr
		public function ICapprovalFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/IC_FTGS_pr_view',$data);
        }
		//ITEM CODE fetch data approve table
		function ICfetchApprovDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['approveList'] = $this->ftgs_model->ICfetchApproveFTGSpr($emp_code);
			return $data['approveList'];
		}
		function getItemCodeAuthoDetails() {
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('Ftgs_PR/ftgs_model');
        $data['autho_code'] = $this->ftgs_model->getItemCodeAuthoDetails();
        return $data;
    }
	
	
	public function ItemCodeAuth_insert()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$editId = $this->input->post('txtftgsId');
			$action = $this->input->post('ftgs_status');
			$Ftgs_action_id = $this->input->post('Ftgs_action_id');
			if ($action == "1") {
            $data = array(
				'action_autho' => $this->input->post('txt_emp_code'),
				'action' => 1,
				'comment' => $this->input->post('txt_comment'),
				'action_date' => $date,
                'action_time' => $time
            );
            $data2 = array(
                'ftgs_pr_id' => $this->input->post('txtftgsId'),
                'emp_code' => $this->input->post('user_id'),
                'action_autho' => $this->input->post('txt_ItemCode_Autho'),
                'level_of' => 4,
                'action' => 0,
                'action_date' => $date,
                'action_time' => $time
            );
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            $this->ftgs_model->ftgsProcessRepAutho($data2);
            
            
            // Email Code Start-
            
					$reciver= $this->input->post('txtItemCodeAuthoEmail');  //PH email
				  
					$ccuser=$this->input->post('txtUserAuthoEmail');
					$subject='Interplant FTGS PR Approved By '.$this->input->post('txtPHName').' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal (http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
		}
		else 
		{
            $data = array(
                'action_autho' => $this->input->post('txt_emp_code'),
                'action' => 2,
                'comment' => $this->input->post('txt_comment'),
                'action_date' => $date,
                'action_time' => $time,
            );
            $data1 = array(
                'ftgs_pr_status' => 2
            );
          
            $this->db->where('ftgs_pr_id', $editId);
            $this->db->update('ftgs_pr_master', $data1);
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            
            	// Email Code Start-
					
					$reciver= $this->input->post('txtUserAuthoEmail');
			
					$subject='Interplant FTGS PR Rejected By '.$this->input->post('txtPHName').' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					//$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
         }
		 $this->load->helper('url');
		$this->load->view('FTGSPR/IC_pendding_FTGS_pr_tbl');
		
	}
	//fetch Item code level
		 function ftgsItemCodeActionData($emp_code,$ftgs_pr_id) 
		 {
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['ftgsActionData'] = $this->ftgs_model->ftgsItemCodeAction($emp_code,$ftgs_pr_id);
			return $data['ftgsActionData'];
		}
		
		
		
		//ION Create---------
		//ION  pendding tbl ftgs pr
		public function ION_penddingTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/ION_pendding_FTGS_pr_tbl');
        }
		//ION pendding view ftgs pr
		public function IONpenddingFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/ION_pendding_FTGS_pr_view',$data);
        }
		//ION fetch data pendding table
		function IONfetchpenddingDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['pendingList'] = $this->ftgs_model->IONfetchPendingFTGSpr($emp_code);
			return $data['pendingList'];
		}
		//ION Reject TBL ftgs pr
		public function ION_rejectTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/ION_reject_FTGS_pr_tbl');
        }
		//ION Reject view ftgs pr
		public function IONrejectFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/ION_FTGS_pr_view',$data);
        }
		//ION fetch data Reject table
		function IONfetchrejectDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['rejectList'] = $this->ftgs_model->IONfetchrejectFTGSpr($emp_code);
			return $data['rejectList'];
		}
		//ION Approved TBL ftgs pr
		public function ION_approveTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/ION_approval_FTGS_pr_tbl');
        }
		//ION Approved view ftgs pr
		public function IONapproveFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/ION_FTGS_pr_view',$data);
        }
		//ION fetch data Approved table
		function IONfetchapproveDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['approveList'] = $this->ftgs_model->IONfetchapproveDetails($emp_code);
			return $data['approveList'];
		}
		//ION fetch  Approved Authority
		function getIONAuthoDetails() {
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('Ftgs_PR/ftgs_model');
        $data['ION_Auth'] = $this->ftgs_model->getIONAuthoDetails();
        return $data;
    }
	public function IONAuth_insert()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$editId = $this->input->post('txtftgsId');
			$action = $this->input->post('ftgs_status');
			$ion_no = $this->input->post('txt_ionNo');
			$Ftgs_action_id = $this->input->post('Ftgs_action_id');
			if ($action == "1") {
            $data = array(
				'action_autho' => $this->input->post('txt_emp_code'),
				'action' => 1,
				'comment' => $this->input->post('txt_comment'),
				'action_date' => $date,
                'action_time' => $time
            );
            $data2 = array(
                'ftgs_pr_id' => $this->input->post('txtftgsId'),
                'emp_code' => $this->input->post('user_id'),
                'action_autho' => $this->input->post('txt_ION_Autho'),
                'level_of' => 5,
                'action' => 0,
                'action_date' => $date,
                'action_time' => $time
            );
			$data1 = array(
				'ftgs_ion_no' => $ion_no
            );
			
			$this->db->where('ftgs_pr_id', $editId);
            $this->db->update('ftgs_pr_master', $data1);
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            $this->ftgs_model->ftgsProcessRepAutho($data2);
            
            
            // Email Code Start-
					//$reciver= $this->input->post('txtPHAuthoEmail');  //PH email
					$reciver= $this->input->post('txtPHAuthoEmail');  //PH email
					$ccuser=$this->input->post('txtUserAuthoEmail');
					$subject='Interplant FTGS PR Approved By '.$this->input->post('txtPHName').' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
					
					
		}
		else 
		{
            $data = array(
                'action_autho' => $this->input->post('txt_emp_code'),
                'action' => 2,
                'comment' => $this->input->post('txt_comment'),
                'action_date' => $date,
                'action_time' => $time,
            );
            $data1 = array(
                'ftgs_pr_status' => 2,
				'ftgs_ion_no' => $ion_no
            );
          
            $this->db->where('ftgs_pr_id', $editId);
            $this->db->update('ftgs_pr_master', $data1);
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            
            	// Email Code Start-
				
					$reciver= $this->input->post('txtUserAuthoEmail');
			
					$subject='Interplant FTGS PR Rejected By '.$this->input->post('txtEmpNameEmail').' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					//$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
         }
		 $this->load->helper('url');
		$this->load->view('FTGSPR/ION_pendding_FTGS_pr_tbl');
		
	}
	//fetch ION Autho level
		 function ftgsIONAuthoActionData($emp_code,$ftgs_pr_id) 
		 {
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['ftgsActionData'] = $this->ftgs_model->ftgsIONAction($emp_code,$ftgs_pr_id);
			return $data['ftgsActionData'];
		}
	//Asset Code Create---------
		//Asset Code  pendding tbl ftgs pr
		public function AssCode_penddingTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/ACC_pendding_FTGS_pr_tbl');
        }
		//Asset Code pendding view ftgs pr
		public function AssCodependFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/ACC_pendding_FTGS_pr_view',$data);
        }
		//Asset Code fetch data pendding table
		function AssCodefetchpendDtl($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['pendingList'] = $this->ftgs_model->ACCfetchPendingFTGSpr($emp_code);
			return $data['pendingList'];
		}	
		//Asset code fetch  Approved Authority
		function getAssetAuthoDetails() {
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('Ftgs_PR/ftgs_model');
        $data['Asset_code'] = $this->ftgs_model->getACCAuthoDetails();
        return $data;
    }
	//fetch Asset Autho level
		 function ftgsACCAuthoActionData($emp_code,$ftgs_pr_id) 
		 {
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['ftgsActionData'] = $this->ftgs_model->ftgsACCAction($emp_code,$ftgs_pr_id);
			return $data['ftgsActionData'];
		}
		public function ASSAuth_insert()
		{
	
		date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$editId = $this->input->post('txtftgsId');
			$action = $this->input->post('ftgs_status');
			$Ftgs_action_id = $this->input->post('Ftgs_action_id');
			$data = array(
				'assetFile_attach_ftgs' =>preg_replace('/\s+/', '_', $_FILES['assetFile_attach_ftgs']['name']),
			);
			$capex_upd=$this->ftgs_model->File_update($editId,$data);	
			//assetFile_attach attachment 	
			if (!empty($_FILES['assetFile_attach_ftgs']['name'])) {//single file upload 
                chmod('./uploads/assetFile_attach_ftgs/', 0777);
				$path   = './uploads/assetFile_attach_ftgs/';
				if (!is_dir($path)) { //create the folder if it's not already exists
					mkdir($path, 0777, TRUE);
				}
			$config = array(
            'upload_path'   => $path,
            'allowed_types' => '*',
            'overwrite'     => 1,                       
        );
        $this->load->library('upload', $config);
		$this->upload->initialize($config);
		if($this->upload->do_upload('assetFile_attach_ftgs')){
		}else{	?>
                <script type="text/javascript">
                    alert("file upload error");
                </script>
            <?php
					
				}
			$capex_upd=$this->ftgs_model->File_update($editId,$data);

            } 
			if ($action == "1") {
            $data = array(
				'action_autho' => $this->input->post('txt_emp_code'),
				'action' => 1,
				'comment' => $this->input->post('txt_comment'),
				'action_date' => $date,
                'action_time' => $time
            );
            $data2 = array(
                'ftgs_pr_id' => $this->input->post('txtftgsId'),
                'emp_code' => $this->input->post('user_id'),
                'action_autho' => $this->input->post('txt_Asset_Autho'),
                'level_of' => 6,
                'action' => 0,
                'action_date' => $date,
                'action_time' => $time
            );
			 
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            $this->ftgs_model->ftgsProcessRepAutho($data2);
            
            
            // Email Code Start-
					$reciver= $this->input->post('txtIONAuthoEmail');  //PH email
					$ccuser=$this->input->post('txtUserAuthoEmail');
					$subject='Interplant FTGS PR Approved By '.$this->input->post('txtPHName').' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
					
					
					
		}
		else 
		{
            $data = array(
                'action_autho' => $this->input->post('txt_emp_code'),
                'action' => 2,
                'comment' => $this->input->post('txt_comment'),
                'action_date' => $date,
                'action_time' => $time,
            );
            $data1 = array(
                'ftgs_pr_status' => 2,
				
            );
          
            $this->db->where('ftgs_pr_id', $editId);
            $this->db->update('ftgs_pr_master', $data1);
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            
            
            	// Email Code Start-
				
					$reciver= $this->input->post('txtUserAuthoEmail');
			
					$subject='Interplant FTGS PR Rejected By '.$this->input->post('txtPHName').' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					//$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
         }

		  $this->load->helper('url');
		$this->load->view('FTGSPR/ACC_pendding_FTGS_pr_tbl');
		}

	//Asset code Reject TBL ftgs pr
		public function ACC_rejectTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/ACC_reject_FTGS_pr_tbl');
        }
		//Asset code Reject view ftgs pr
		public function ACCrejectFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/ACC_FTGS_pr_view',$data);
        }
		//Asset code fetch data Reject table
		function ACCfetchrejectDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['rejectList'] = $this->ftgs_model->ACCfetchrejectFTGSpr($emp_code);
			return $data['rejectList'];
		}
		//Asset code Approved TBL ftgs pr
		public function ACC_approveTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/ACC_approval_FTGS_pr_tbl');
        }
		//Asset code Approved view ftgs pr
		public function ACCapproveFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/ACC_FTGS_pr_view',$data);
        }
		//Asset code fetch data Approved table
		function ACCfetchapproveDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['approveList'] = $this->ftgs_model->ACCfetchapproveDetails($emp_code);
			return $data['approveList'];
		}
		
	//PO Create ---------
		//PO  pendding tbl ftgs pr
		public function POCret_penddingTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/PO_pendding_FTGS_pr_tbl');
        }
		//PO  pendding view ftgs pr
		public function POCretpendFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/PO_pendding_FTGS_pr_view',$data);
        }
			
		//PO fetch data pendding table
		function POCodefetchpendDtl($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['pendingList'] = $this->ftgs_model->POfetchPendingFTGSpr($emp_code);
			return $data['pendingList'];
		}
		//PO Reject TBL ftgs pr
		public function PO_rejectTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/po_reject_FTGS_pr_tbl');
        }
		//PO Reject view ftgs pr
		public function POrejectFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/PO_FTGS_pr_view',$data);
        }
		//PO fetch data Reject table
		function POfetchrejectDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['rejectList'] = $this->ftgs_model->POfetchrejectFTGSpr($emp_code);
			return $data['rejectList'];
		}
		//PO Approved TBL ftgs pr
		public function po_approveTBL() 
		{
			$this->load->helper('url');
			$this->load->view('FTGSPR/PO_approval_FTGS_pr_tbl');
        }
		//PO Approved view ftgs pr
		public function POapproveFTGSview($ftgs_pr_id) 
		{
			$data['ftgs_pr_id'] = $ftgs_pr_id;
			$this->load->helper('url');
			$this->load->view('FTGSPR/PO_FTGS_pr_view',$data);
        }
		//PO fetch data Approved table
		function POfetchapproveDetails($emp_code) {
			$this->load->helper('url');
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['approveList'] = $this->ftgs_model->POfetchapproveDetails($emp_code);
			return $data['approveList'];
		}
		//fetch PO Autho level
		 function ftgsPOAuthoActionData($emp_code,$ftgs_pr_id) 
		 {
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['ftgsActionData'] = $this->ftgs_model->ftgsIOAction($emp_code,$ftgs_pr_id);
			return $data['ftgsActionData'];
		}
		public function IOAuth_insert()
		{
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-Y');
			$time = date("h:i A");
			$editId = $this->input->post('txtftgsId');
			$action = $this->input->post('ftgs_status');
			$Ftgs_action_id = $this->input->post('Ftgs_action_id');
			if ($action == "1") {
            $data = array(
				'action_autho' => $this->input->post('txt_emp_code'),
				'action' => 1,
				'comment' => $this->input->post('txt_comment'),
				'action_date' => $date,
                'action_time' => $time
            );
			$data1 = array(
                'ftgs_pr_status' => 3
            );
			 $this->db->where('ftgs_pr_id', $editId);
            $this->db->update('ftgs_pr_master', $data1);
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            
            
            // Email Code Start-
					$reciver= $this->input->post('txtUserAuthoEmail');  //user 
				
					$subject='Interplant FTGS PR Approved By '.$this->input->post('txtPHName').' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
				
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
          }
		else 
		{
            $data = array(
                'action_autho' => $this->input->post('txt_emp_code'),
                'action' => 2,
                'comment' => $this->input->post('txt_comment'),
                'action_date' => $date,
                'action_time' => $time,
            );
            $data1 = array(
                'ftgs_pr_status' => 2
            );
          
            $this->db->where('ftgs_pr_id', $editId);
            $this->db->update('ftgs_pr_master', $data1);
            $this->ftgs_model->updateuserAction($data, $editId, $Ftgs_action_id);
            
            
            	// Email Code Start-
				
					$reciver= $this->input->post('txtUserAuthoEmail');
			
					$subject='Interplant FTGS PR Rejected By '.$this->input->post('txtPHName').' Against  PR NO.  '.$editId.' ';
					$message='<ol>
								<li><b>FTGS PR No:</b>  '.$editId.'</li>
								<li><b>FTGS PR Owner:</b>  '.$this->input->post('txtEmpNameEmail'). '</li>
								<li><b>Plant:</b>  '.$this->input->post('txtEmpPlant'). '</li>
								<li><b>Department:</b>  '.$this->input->post('txtEmpDept'). '</li>
								<li><b>FTGS PR Date:</b>  '.$this->input->post('txtPRDate'). '</li>
								<li><b>Total Amount:</b>  '.$this->input->post('txtTotalAmt').'</li>
								<li><b>Approver Comment:</b>  '.$this->input->post('txt_comment').'</li>
								
							</ol>
							Kindly visit your PR Portal(http://rucha.co.in/portal)';
					$this->load->library('email');
					$confing =array(
						'protocol'=>'none',
						'smtp_host'=>"relay-hosting.secureserver.net",
						'smtp_port'=>465,
						'smtp_user'=>"no-reply@rucha.co.in",
						'smtp_pass'=>'pass@1234',
						'mailtype'=>'html'  
					);
					$this->email->initialize($confing);
					$this->email->set_newline("\r\n");
					$this->email->from('no-reply@rucha.co.in');
					$this->email->to($reciver);
					//$this->email->cc($ccuser);
					$this->email->subject($subject);
					$this->email->message($message);
					$this->email->send();
					// Email Code End
         }
		 $this->load->helper('url');
		$this->load->view('FTGSPR/PO_pendding_FTGS_pr_tbl');
		
	}
	function deptAuthNavBarStatus($emp_code) 
	{
        $this->load->database();
		$this->load->model('Ftgs_PR/ftgs_model');
        $data['dept_autho'] = $this->ftgs_model->deptAuthNavBarStatus($emp_code);
        return $data;
    }
	function plantAuthNavBarStatus($emp_code) 
	{
        $this->load->database();
		$this->load->model('Ftgs_PR/ftgs_model');
        $data['PlantHead'] = $this->ftgs_model->plantAuthNavBarStatus($emp_code);
        return $data;
    }
	function ItemCodeAuthNavBarStatus($emp_code) 
	{
        $this->load->database();
		$this->load->model('Ftgs_PR/ftgs_model');
        $data['itemcode'] = $this->ftgs_model->ItemCodeAuthNavBarStatus($emp_code);
        return $data;
    }
	function IONCreateAuthNavBarStatus($emp_code) 
	{
        $this->load->database();
		$this->load->model('Ftgs_PR/ftgs_model');
        $data['IONCreate'] = $this->ftgs_model->IONCreateAuthNavBarStatus($emp_code);
        return $data;
    }
	function AssetCodeAuthNavBarStatus($emp_code) 
	{
        $this->load->database();
		$this->load->model('Ftgs_PR/ftgs_model');
        $data['AssetCode'] = $this->ftgs_model->AssetCodeAuthNavBarStatus($emp_code);
        return $data;
    }
	function POCreationAuthNavBarStatus($emp_code) 
	{
        $this->load->database();
		$this->load->model('Ftgs_PR/ftgs_model');
        $data['POCreation'] = $this->ftgs_model->POCreationAuthNavBarStatus($emp_code);
        return $data;
    }
	function approval_status($ftgs_pr_id) 
	{
        $this->load->database();
		$this->load->model('Ftgs_PR/ftgs_model');
        $data['approval'] = $this->ftgs_model->approval_status($ftgs_pr_id);
        return $data['approval'];
    }
	public function ftgs_item_list($ftgs_pr_id)
		{
			
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model');  
			$data['item']=$this->ftgs_model->ftgs_item_list($ftgs_pr_id);  
		  	return $data['item'];
		}
	//fetch upload attachment ftgs 
		public function fetchAssetAttach($ftgs_pr_id) 
		{
			$this->load->helper('url');
			$this->load->database();  
			$this->load->model('Ftgs_PR/ftgs_model'); 
			$data['filefetch'] = $this->ftgs_model->fetchAssetAttach($ftgs_pr_id);
			return $data['filefetch'];
			
		}
	    //fetch email Dept Head
		function fetchDHMailDetails($DHCode)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['DHEmail'] = $this->ftgs_model->fetchDHMailDetails($DHCode);
			return $data;
		}
		
		
		
				//fetch email plant Head
		function fetchPHMailDetails($IOCode)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['PhEmail'] = $this->ftgs_model->fetchPHMailDetails($IOCode);
			return $data;
		}
		//fetch email Item Code Head
		function fetchItemCodeMailDetails($ICCode)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['itemCodeEmail'] = $this->ftgs_model->fetchItemCodeMailDetails($ICCode);
			return $data;
		}
		//fetch email ION  Head
		function fetchIONMailDetails($IONCode)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['IONEmail'] = $this->ftgs_model->fetchIONMailDetails($IONCode);
			return $data;
		}
		//fetch email Asset Head
		function fetchAssetMailDetails($ACCCode)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['AssetEmail'] = $this->ftgs_model->fetchAssetMailDetails($ACCCode);
			return $data;
		}
		
		
		

		//fetch email PO Head
		function fetchPoCreateMailDetails($emp_code)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['POCreateEmail'] = $this->ftgs_model->fetchPoCreateMailDetails($emp_code);
			return $data;
		}
		//fetch email User Head
		function fetchUserMailDetails($ftgs_pr_id)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['UserEmail'] = $this->ftgs_model->fetchUserMailDetails($ftgs_pr_id);
			return $data;
		}
		//fetch User Name
		function fetchEmpNameMailDetails($emp_code)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['emp_Name'] = $this->ftgs_model->fetchEmpNameMailDetails($emp_code);
			return $data;
		}
		//fetch User Plant
		function getUserPlant($ftgs_pr_id)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['UserPlant'] = $this->ftgs_model->getUserPlant($ftgs_pr_id);
			return $data;
		}
		//fetch User Department
		function getUserDept($emp_dept)
		{
			$this->load->database();
			$this->load->model('Ftgs_PR/ftgs_model');
			$data['UserDept'] = $this->ftgs_model->getUserDept($emp_dept);
			return $data;
		}
}
	
?>