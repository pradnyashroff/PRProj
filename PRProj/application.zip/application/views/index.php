 <?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

 

 <html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Portal Index</title>
     	   <?php include_once 'purchase/styles.php'; ?>
<link href="https://fonts.googleapis.com/css?family=Exo&display=swap" rel="stylesheet">
</head>
<body class="hold-transition skin-blue sidebar-mini" >
 
      	   <?php include_once 'headside.php'; ?>

 
 
 
 
 
 
 <!-- Content Wrapper. Contains page content -->
  <div class="">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
  <section class="content" style="    padding-top: 5%;  padding-left: 10%;  padding-right: 10%;">
  
   <div class="row">
    <div class="col-lg-12 col-xs-12" >
	<center>
<h3> Select Your Department </h3><br><br>	</center>
	
	</div>
        <div class="col-lg-4 col-xs-6" >
          <!-- small box -->
		  <a href="<?php echo site_url('PR/kanban/pr_home') ?>" >
              
          <div class="small-box bg-skincolor" style="border-radius:10px;">
            <div class="inner">

         <p>Sourcing, Inspection <br> & Stores</p>
            </div>
         
            
          
          </div>
		    </a>
        </div>
        <!-- ./col -->
        <div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-skincolor">
            <div class="inner">

              <p>Testing & <br> Validation</p>
            </div>
            
            
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-skincolor">
            <div class="inner">

              <p>NPD</p>
            </div>
           
           
          </div>
        </div>
		 <div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-skincolor">
            <div class="inner">

              <p>Product Development</p>
            </div>
           
           
          </div>
        </div>
        <!-- ./col -->
       
		        <div class="col-lg-4 col-xs-6">
				<div class="small-box bg-skincolor">
            <div class="inner">

              <p>UI/UX/GD Projects</p>
            </div>
            
           
          </div>
				
</div>
 <div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-skincolor">
            <div class="inner">

              <p>Marketing & Sales</p>
            </div>
           
           
          </div>
        </div>
  <div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-skincolor">
            <div class="inner">

              <p>Service</p>
            </div>
            
          </div>
        </div>

 <div class="col-lg-4 col-xs-6">
   <div class="small-box bg-skincolor">
            <div class="inner">

              <p>Fin. & Accounts</p>
            </div>
            
            
          </div>
</div>

<div class="col-lg-4 col-xs-6">
   <div class="small-box bg-skincolor">
            <div class="inner">

              <p>HR</p>
            </div>
          
           
          </div>
</div>
        <!-- ./col -->
      </div>
     
  
       <!-- /.row -->
    </section><!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

       	   <?php include_once 'PR/scripts.php'; ?>

  
  </body>
</html>