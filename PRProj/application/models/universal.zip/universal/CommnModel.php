<?php

class CommnModel extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function fetch_dept_nm($dept_id) {

        $condition = "dept_code =" . "'" . $dept_id . "'";
        $this->db->select('dept_name');
        $this->db->from('department_master');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->dept_name;
        } else {
            return false;
        }
    }

//        function findGradeByEmpCode($emp_code)//Full Department name from dept_master
//        {
//            echo '';
//            $condition = "emp_code =" . "'" . $emp_code . "'";
//        $this->db->select('grade_id');
//        $this->db->from('employee_master');
//        $this->db->where($condition);
//        $query = $this->db->get();
//        
//        if ($query->num_rows() >= 1) {
//            $emp_grade=$query->row()->grade_id;
//             
//            return $query->row()->grade_id;
//        } else {
//            return false;
//        }
//        
//        }


    public function getGradeDetails($emp_code) {

        $condition = " em.grade_id=gr.grade_id and emp_code =" . "'" . $emp_code . "'";
        $this->db->select('gr.grade');
        $this->db->from('employee_master em, grade_mst gr');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->grade;
        } else {
            return false;
        }
    }

    public function getVehicleDetailsByGrade($grade_id) {
        echo 'calling modle method here......';
        $condition = "vg.veh_id=vm.veh_id and vg.grade_id =" . "'" . $grade_id . "'";
        $this->db->select("vm.vehicle,vm.veh_id");
        $this->db->from('vehicle_grid vg, vehicle_mst vm');
        $this->db->where($condition);
        $query = $this->db->get();

        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }

    public function addLocalReimDetails($data) {
        $this->load->database();
        $this->db->insert('locrim_clm_detail', $data);
    }
     public function addLocalReimDetailsDraft($data) {
        $this->load->database();
        $this->db->insert('locrim_clm_detail', $data);
    }
     public function addLocalReimClaim($data) {
        $this->load->database();
        $this->db->insert('locrim_clm_mst', $data);
    }
    
   
    public function fetchLocalReimDetails($emp_code) {
        $condition = "trvl_mode=veh_id and lrcd_status = 0 and dynamic_id =" . "'" . $emp_code . "'";
        $this->db->select('*');
        $this->db->from('locrim_clm_detail,vehicle_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
    public function fetchLocalReimDraftDetails($emp_code) {
        $condition = "lrcd_status=0 and emp_code =" . "'" . $emp_code . "'";
        $this->db->select('*');
        $this->db->from('locrim_clm_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
     public function fetchLocalReimApprovedDetails($emp_code) {
        $condition = "lrcd_status=0 and emp_code =" . "'" . $emp_code . "'";
        $this->db->select('*');
        $this->db->from('locrim_clm_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
    
   public function fetchLocalReimDetailsEdit($lrcd_id) {
        $condition = "trvl_mode=veh_id and lrcd_id =" . "'" . $lrcd_id . "'";
        $this->db->select('*');
        $this->db->from('locrim_clm_detail,vehicle_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    public function get_by_id($id)
	{
		  $condition = "CURDATE() BETWEEN fr.app_from and fr.app_to and ld.trvl_mode=fr.veh_id and ld.trvl_mode= vm.veh_id and ld.lrcd_id =" . "'" . $id . "'";
        $this->db->select('*');
        $this->db->from('locrim_clm_detail ld,vehicle_mst vm, fule_rate  fr');
        $this->db->where($condition);
        $query = $this->db->get();
        
		return $query->row();
	}
         public function getRateFromVehicle($id)
	{
        $condition = "CURDATE() BETWEEN app_from and app_to and veh_id =" . "'" . $id . "'";
        $this->db->select('*');
        $this->db->from('fule_rate');
        $this->db->where($condition);
        $query = $this->db->get();
        
		return $query->row();
	}
    public function updateConvensesData($data, $editId) {
        $this->db->where('lrcd_id', $editId);
        $this->db->update('locrim_clm_detail',$data);
        }
        
        public function localClaimDetails($lrcm_id) {
        $condition = "lrcm_id =" . "'" . $lrcm_id . "'";

        $this->db->select('*');
        $this->db->from('locrim_clm_mst');
        $this->db->where($condition);
        $query = $this->db->get();

        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
      public function localClaimDetailsApproal($lrcm_id) {
        $condition = "lcm.emp_code=em.emp_code and em.emp_dept=dm.dept_code and em.grade_id=gm.grade_id and lcm.lrcm_id=" . "'" . $lrcm_id . "'";
        $this->db->select('lcm.lrcm_id, em.emp_code, em.emp_name, lcm.plant_code, lcm.reg_date, gm.grade, dm.dept_name');
        $this->db->from('locrim_clm_mst lcm, employee_master em, department_master dm, grade_mst gm');
        $this->db->where($condition);
        $query = $this->db->get();

        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }

     public function fetchLocalReimDetailsByClaimId($lrcm_id) {
        $condition = "trvl_mode=veh_id and lrcd_status = 0 and dynamic_id =" . "'" . $lrcm_id . "'";
        $this->db->select('*');
        $this->db->from('locrim_clm_detail,vehicle_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    function deleterecords($id)
    {
        $this->db->query("delete from locrim_clm_detail where lrcd_id='".$id."'");
    } 
       public function fetchReportingDetails($emp_code) {

        $condition = "rep_mst_status=1 and emp_code =" . "'" . $emp_code . "'";
        $this->db->select('reporting_autho');
        $this->db->from('reporting_grid');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->reporting_autho;
        } else {
            return false;
        }
    }
     public function addLocalReimClaimDraft($data, $UpdateId) {
        $this->db->where('lrcm_id', $UpdateId);
        $this->db->update('locrim_clm_mst',$data);
        }
    
   
      public function localReimClaimProcess($dataProcess) {
        $this->load->database();
        $this->db->insert('local_rim_status', $dataProcess);
        }
   public function fetchLocalReimApprovalDetails($emp_code) {
     
        $condition = "ls.lrcm_id=lm.lrcm_id and lm.emp_code=em.emp_code and ls.actual_action = 0 and ls.level_of=1 and ls.rep_autho=" . "'" . $emp_code . "'";
        $this->db->select('em.emp_name,lm.lrcm_id,lm.total_amt,lm.reg_date');
        $this->db->from('locrim_clm_mst lm, employee_master em, local_rim_status  ls');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
     public function updateClaimAction($data, $editId,$local_rim_id) {
        $condition = "lrcm_id=" . "'" . $editId . "' and local_rim_id=" . "'" . $local_rim_id ."'";
        $this->db->where($condition);
        $this->db->update('local_rim_status',$data);
        }
        
        
    public function getSanctionAuthoDetails() {

        $condition = "sam_status=1";
        $this->db->select('emp_code as autho_code');
        $this->db->from('saction_autho_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->autho_code;
        } else {
            return false;
        }
    }
    
    public function localReimClaimProcessRepAutho($data2) {
        $this->load->database();
        $this->db->insert('local_rim_status', $data2);
        }
        
         public function getClaimerDetails($lrcm_id) {

        $condition = "lrcm_id =" . "'" . $lrcm_id . "'";
        $this->db->select('emp_code as claimer');
        $this->db->from('locrim_clm_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->claimer;
        } else {
            return false;
        }
    }
    
     public function fetchLocalReimSancAuthoDetails($emp_code) {
     
        $condition = "ls.lrcm_id=lm.lrcm_id and lm.emp_code=em.emp_code and ls.actual_action = 0 and ls.level_of=2 and ls.rep_autho=" . "'" . $emp_code . "'";
        $this->db->select('em.emp_name,lm.lrcm_id,lm.total_amt,lm.reg_date');
        $this->db->from('locrim_clm_mst lm, employee_master em, local_rim_status  ls');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
      public function updateClaimActionBySancAutho($data, $lrcm_id,$auto_code,$final_local_rim_id) {
        $condition = "lrcm_id=" . "'" . $lrcm_id . "' and rep_autho=" . "'" . $auto_code . "' and local_rim_id=" . "'" . $final_local_rim_id . "'";
        $this->db->where($condition);
        $this->db->update('local_rim_status',$data);
        }
        
        
    
    
      public function fetchLocalReimRejectDetails($emp_code) {
       
        $condition = "lrcd_status=2 AND emp_code=" . "'" . $emp_code . "'";
        $this->db->select('lrcm_id,total_amt,reg_date');
        $this->db->from('locrim_clm_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
     public function localClaimDetailsHodActionStatus($lrcm_id,$emp_code) {
         
        $sql = "SELECT em.emp_name,ls.local_rim_id,ls.emp_code,ls.actual_action, ls.action_date, ls.action_time , ls.comment"
                . " FROM local_rim_status ls, employee_master em "
                . "WHERE ls.lrcm_id=".$lrcm_id ." and ls.emp_code=".$emp_code ." "
                . "and ls.level_of=1 AND em.emp_code=ls.rep_autho  "
                . "ORDER BY ls.local_rim_id DESC LIMIT 0, 1";
        $query = $this->db->query($sql);
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
      public function localClaimDetailsSanAuthoActionStatus($lrcm_id,$emp_code) {
         
        $sql = "SELECT em.emp_name,ls.local_rim_id,ls.emp_code,ls.actual_action, ls.action_date, ls.action_time , ls.comment"
                . " FROM local_rim_status ls, employee_master em "
                . "WHERE ls.lrcm_id=".$lrcm_id ." and ls.emp_code=".$emp_code ." "
                . "and ls.level_of=2 AND em.emp_code=ls.rep_autho  "
                . "ORDER BY ls.local_rim_id DESC LIMIT 0, 1";
        $query = $this->db->query($sql);
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    public function localClaimDetailsLastApprovalDetils($emp_code,$lrcm_id) {
          $sql = "SELECT local_rim_id,rep_autho,level_of,lrcm_id FROM local_rim_status WHERE rep_autho=".$emp_code." and lrcm_id=".$lrcm_id." and actual_action=0 and level_of=2 ORDER BY local_rim_id DESC LIMIT 0, 1";
        $query = $this->db->query($sql);

        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
        
     public function localClaimDetailsHodActionData($emp_code,$lrcm_id) {
             $sql = "SELECT local_rim_id FROM local_rim_status WHERE rep_autho=".$emp_code." and lrcm_id=".$lrcm_id." and actual_action=0 and level_of=1 ORDER BY local_rim_id DESC LIMIT 0, 1";
            $query = $this->db->query($sql);

        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
       public function fetchLocalReimApprovedDetailsTbl($emp_code) {
        $condition = "ls.emp_code=lm.emp_code and ls.level_of=2 and ls.action=1 and ls.lrcm_id=lm.lrcm_id and lm.lrcd_status=3 and ls.emp_code =" . "'" . $emp_code . "'";
        $this->db->select('lm.lrcm_id,lm.total_amt,lm.reg_date,ls.action_date,ls.action');
        $this->db->from('local_rim_status ls, locrim_clm_mst lm ');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
      public function fetchLocalReimPendingDetails($emp_code) {
        $condition = "lm.lrcm_id=ls.lrcm_id and ls.rep_autho=em.emp_code and ls.action=0 and lm.lrcd_status=1 and ls.emp_code =" . "'" . $emp_code . "'";
        $this->db->select('lm.lrcm_id,lm.total_amt,lm.reg_date,em.emp_name');
        $this->db->from('locrim_clm_mst lm ,local_rim_status ls ,employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
  public function fetchLocalReimApprovalHODClaim($emp_code) {
        $condition = "lm.lrcm_id=ls.lrcm_id and ls.action=1 and ls.level_of=1 and ls.emp_code=em.emp_code
        and ls.rep_autho =" . "'" . $emp_code . "'";
        $this->db->select('lm.lrcm_id,em.emp_name,lm.total_amt,lm.reg_date');
        $this->db->from('locrim_clm_mst lm, local_rim_status ls, employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    public function localClaimDetailsHodApproved($lrcm_id,$emp_code) {
         
        $sql = "SELECT lm.total_amt,ls.action_date,ls.action_time,ls.comment FROM locrim_clm_mst lm, local_rim_status ls
WHERE lm.lrcm_id=ls.lrcm_id and ls.action=1 and ls.level_of=1 and ls.rep_autho=".$emp_code." AND ls.lrcm_id=".$lrcm_id."";
        $query = $this->db->query($sql);
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
     public function fetchLocalReimRejectHODClaim($emp_code) {
        $condition = "lm.lrcm_id=ls.lrcm_id and ls.action=2 and ls.level_of=1 and ls.emp_code=em.emp_code
        and ls.rep_autho =" . "'" . $emp_code . "'";
        $this->db->select('lm.lrcm_id,em.emp_name,lm.total_amt,lm.reg_date');
        $this->db->from('locrim_clm_mst lm, local_rim_status ls, employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    public function localClaimDetailsHodReject($lrcm_id,$emp_code) {
         
        $sql = "SELECT ls.local_rim_id, lm.total_amt,ls.action_date,ls.action_time,ls.comment FROM locrim_clm_mst lm, local_rim_status ls WHERE lm.lrcm_id=ls.lrcm_id and ls.action=2 and ls.level_of=1 and ls.rep_autho=".$emp_code." AND ls.lrcm_id=".$lrcm_id."";
        $query = $this->db->query($sql);
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
      public function fetchLocalReimSancAuthoRejectDetails($emp_code) {
     
        $condition = "lm.lrcm_id=ls.lrcm_id and ls.action=2 and ls.level_of=2 and ls.emp_code=em.emp_code
        and ls.rep_autho =" . "'" . $emp_code . "'";
        $this->db->select('lm.lrcm_id,em.emp_name,lm.total_amt,lm.reg_date');
        $this->db->from('locrim_clm_mst lm, local_rim_status ls, employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
     public function localClaimDetailsSancAuthoReject($lrcm_id,$emp_code) {
         
        $sql = "SELECT ls.local_rim_id, lm.total_amt,ls.action_date,ls.action_time,ls.comment FROM locrim_clm_mst lm, local_rim_status ls WHERE lm.lrcm_id=ls.lrcm_id and ls.action=2 and ls.level_of=2 and ls.rep_autho=".$emp_code." AND ls.lrcm_id=".$lrcm_id."";
        $query = $this->db->query($sql);
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
  public function fetchLocalReimApprovalSancAutho($emp_code) {
        $condition = "lm.lrcm_id=ls.lrcm_id and ls.action=1 and ls.level_of=2 and ls.emp_code=em.emp_code
        and ls.rep_autho =" . "'" . $emp_code . "'";
        $this->db->select('lm.lrcm_id,em.emp_name,lm.total_amt,lm.reg_date');
        $this->db->from('locrim_clm_mst lm, local_rim_status ls, employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
     public function localClaimDetailsSancApproved($emp_code) {
        $condition = "lm.lrcm_id=ls.lrcm_id and ls.action=1 and ls.level_of=2 and ls.emp_code=em.emp_code
        and ls.rep_autho =" . "'" . $emp_code . "'";
        $this->db->select('lm.lrcm_id,em.emp_name,lm.total_amt,lm.reg_date');
        $this->db->from('locrim_clm_mst lm, local_rim_status ls, employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    public function localClaimDetailsSancApprovedReq($lrcm_id,$emp_code) {
         
        $sql = "SELECT lm.total_amt,ls.action_date,ls.action_time,ls.comment FROM locrim_clm_mst lm, local_rim_status ls
        WHERE lm.lrcm_id=ls.lrcm_id and ls.action=1 and ls.level_of=2 and ls.rep_autho=".$emp_code." AND ls.lrcm_id=".$lrcm_id."";
        $query = $this->db->query($sql);
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
      public function localClaimDetailsStatusLog($lrcm_id) {
         
        $sql = "SELECT ls.lrcm_id,ls.actual_action,ls.comment,ls.action_date,ls.action_time,em.emp_name FROM local_rim_status ls, employee_master em WHERE em.emp_code=ls.rep_autho and ls.lrcm_id=".$lrcm_id."";
        $query = $this->db->query($sql);
        if ($query->num_rows() >= 1) {
            return $query;
        } else {
            return false;
        }
    }
    
    
     public function getAttachmentDownload($lrcm_id) {

        $condition = "lrcm_id =" . "'" . $lrcm_id . "'";
        $this->db->select('pic_file');
        $this->db->from('locrim_clm_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->pic_file;
        } else {
            return false;
        }
    }

       public function sancAuthNavBarStatus($emp_code) {

        $condition = "sam_status=1 and emp_code  =" . "'" . $emp_code . "'";
        $this->db->select('sam_id');
        $this->db->from('saction_autho_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->sam_id;
        } else {
            return false;
        }
    }
    
    public function repoAuthNavBarStatus($emp_code) {

        $condition = "rep_mst_status=1 and reporting_autho  =" . "'" . $emp_code . "'";
        $this->db->select('reporting_autho');
        $this->db->from('reporting_grid');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->reporting_autho;
        } else {
            return false;
        }
    }
    
        public function fetchHODMailDetailsForClaimer($emp_code) {
        $condition = "rg.reporting_autho=em.emp_code  and rg.emp_code =" . "'" . $emp_code . "'";
        $this->db->select('em.emp_email As hodEmail');
        $this->db->from('reporting_grid rg , employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->hodEmail;
        } else {
            return false;
        }
    }
    
     public function fetchSancAuthoMailDetailsForClaimer() {
        $condition = "sm.emp_code=em.emp_code and sm.sam_status=1";
        $this->db->select('em.emp_email As SancAuthoEmail');
        $this->db->from('saction_autho_mst sm, employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->SancAuthoEmail;
        } else {
            return false;
        }
    }
      public function fetchVoucherDate($lrcm_id) {

        $condition = "lrcm_id =" . "'" . $lrcm_id . "'";
        $this->db->select('reg_date');
        $this->db->from('locrim_clm_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->reg_date;
        } else {
            return false;
        }
    }
    
         public function fetchUserMailDetails($lrcm_id) {
        $condition = "em.emp_code=lm.emp_code and lrcm_id =" . "'" . $lrcm_id . "'";
        $this->db->select('em.emp_email');
        $this->db->from('locrim_clm_mst lm, employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->emp_email;
        } else {
            return false;
        }
    }
    
       public function fetchEmpNameForMail($lrcm_id) {

        $condition = "em.emp_code=lm.emp_code and lrcm_id =" . "'" . $lrcm_id . "'";
        $this->db->select('em.emp_name');
        $this->db->from('locrim_clm_mst lm, employee_master em');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->emp_name;
        } else {
            return false;
        }
    }
      public function showSancAuthoReportAccept($txtFromDate,$txtToDate) {
        
        $condition = "lm.lrcm_id=ls.lrcm_id and ls.action=1 and ls.level_of=2 and ls.emp_code=em.emp_code
        and lm.lrcd_status=3 and em.emp_dept=dm.dept_code and em.plant_code=pm.plant_code and lm.reg_date BETWEEN  " . "'" . $txtFromDate . "'" . " AND " . "'" . $txtToDate . "'";
         $this->db->select('lm.lrcm_id,em.emp_name,lm.total_amt,lm.reg_date,em.emp_code,dm.dept_name,pm.plant_name');
$this->db->from('locrim_clm_mst lm, local_rim_status ls, employee_master em, department_master dm, plant_master pm');

$this->db->where($condition);
$query = $this->db->get();

        
            return $query->result();
           
    }
    
     public function getDraftJustification($lrcm_id) {

        $condition = "lrcm_id =" . "'" . $lrcm_id . "'";
        $this->db->select('justification');
        $this->db->from('locrim_clm_mst');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->justification;
        } else {
            return false;
        }
    }
    
     public function higherAuthNavBarStatus($emp_code) {

        $condition = " ocha_status=1 and level=1 and emp_code  =" . "'" . $emp_code . "'";
        $this->db->select('ocha_id');
        $this->db->from('other_claim_higher_autho');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->ocha_id;
        } else {
            return false;
        }
    }
    
    public function mdOfficeAuthNavBarStatus($emp_code) {

        $condition = " ocha_status=1 and level=2 and emp_code  =" . "'" . $emp_code . "'";
        $this->db->select('ocha_id');
        $this->db->from('other_claim_higher_autho');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->ocha_id;
        } else {
            return false;
        }
    }
     //Additonal Development Of Local Report 2019-10-26
       public function getPlantNameDetails($plant_code) {

        $condition = " plant_code =" . "'" . $plant_code . "'";
        $this->db->select('plant_name');
        $this->db->from('plant_master');
        $this->db->where($condition);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row()->plant_name;
        } else {
            return false;
        }
    }

}

